// Reset logs every time Chrome starts
chrome.runtime.onStartup.addListener(() => {
  chrome.storage.local.set({ logs: [] });
});