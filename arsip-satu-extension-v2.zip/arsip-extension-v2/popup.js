
let running = false;
const $ = (s) => document.querySelector(s);

const logEl        = $('#log');
const statusTextEl = $('#statusText');
const delayEl      = $('#delay');
const barEl        = $('#bar');
const mascotEl     = $('#mascot');
const dotEl        = $('#dot');
const processedEl  = $('#processed');
const remainingEl  = $('#remaining');
const progressFill = $('#progressFill');
const s1El = $('#s1'), s2El = $('#s2'), s3El = $('#s3');

function setStage(n){
  [s1El, s2El, s3El].forEach((el, i) => {
    el.className = 'stage';
    if(i < n - 1)        el.classList.add('done');
    else if(i === n - 1) el.classList.add('active');
  });
}

function setRunningUI(isRunning){
  if(isRunning){
    statusTextEl.textContent = 'Running…';
    barEl.classList.add('running');
    mascotEl.classList.add('run');
    dotEl.classList.add('running');
  } else {
    barEl.classList.remove('running');
    mascotEl.classList.remove('run');
    dotEl.classList.remove('running');
    setStage(0);
  }
}

function renderLogs(logs){
  const kept = (logs || []).slice(-6);
  // Render with color spans
  logEl.innerHTML = kept.map(line => {
    const ts = line.match(/^\[[\d:]+\]/)?.[0] || '';
    const body = line.slice(ts.length);
    const tsSpan = ts ? `<span class="log-ts">${ts}</span>` : '';
    let cls = '';
    if(/✅|Selesai|berhasil/i.test(body))     cls = 'log-ok';
    else if(/Processed:|Batch:/i.test(body))   cls = 'log-ok';
    else if(/Klik|Centang/i.test(body))        cls = 'log-info';
    else if(/⚠️|retry|tidak ada/i.test(body)) cls = 'log-warn';
    return `${tsSpan}<span class="${cls}">${escHtml(body)}</span>`;
  }).join('\n');
  logEl.scrollTop = logEl.scrollHeight;
}

function escHtml(s){
  return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function flashCounter(el){
  el.classList.add('flash');
  setTimeout(() => el.classList.remove('flash'), 400);
}

function updateProgress(processed, remaining){
  const total = processed + remaining;
  if(total > 0) progressFill.style.width = ((processed / total) * 100) + '%';
}

async function persistLog(line){
  const ts = new Date().toLocaleTimeString();
  const s = await chrome.storage.local.get(['logs']);
  const logs = Array.isArray(s.logs) ? s.logs : [];
  logs.push(`[${ts}] ${line}`);
  await chrome.storage.local.set({logs: logs.slice(-50)});
}

async function execContent(){
  const [tab] = await chrome.tabs.query({active: true, currentWindow: true});
  chrome.scripting.executeScript({target: {tabId: tab.id}, files: ['content.js']});
}

async function initState(){
  const s = await chrome.storage.local.get(['running','delay','processed','remaining','logs','stage']);
  running = !!s.running;
  if(s.delay) delayEl.value = s.delay;
  setRunningUI(running);
  if(!running) statusTextEl.textContent = 'Siap.';
  if(typeof s.processed === 'number') processedEl.textContent = s.processed;
  if(typeof s.remaining === 'number'){
    remainingEl.textContent = s.remaining;
    updateProgress(s.processed || 0, s.remaining);
  }
  if(typeof s.stage === 'number') setStage(s.stage);
  renderLogs(Array.isArray(s.logs) ? s.logs : []);
}

$('#start').addEventListener('click', async () => {
  const delay = parseInt(delayEl.value || '2000', 10);
  running = true;
  await chrome.storage.local.remove(['totalInitial']);
  await chrome.storage.local.set({running, delay, processed: 0});
  processedEl.textContent = '0';
  remainingEl.textContent = '—';
  progressFill.style.width = '0%';
  setRunningUI(true);
  setStage(1);
  statusTextEl.textContent = 'Running…';
  await persistLog('Mulai proses arsip…');
  execContent();
});

$('#stop').addEventListener('click', async () => {
  running = false;
  await chrome.storage.local.set({running});
  setRunningUI(false);
  statusTextEl.textContent = 'Dihentikan.';
  await persistLog('Dihentikan secara manual.');
});

chrome.storage.onChanged.addListener((changes) => {
  if(changes.running){
    running = !!changes.running.newValue;
    setRunningUI(running);
    if(!running && statusTextEl.textContent === 'Running…')
      statusTextEl.textContent = 'Selesai ✓';
  }
  if(changes.delay?.newValue) delayEl.value = changes.delay.newValue;

  if(changes.processed && typeof changes.processed.newValue === 'number'){
    processedEl.textContent = changes.processed.newValue;
    flashCounter(processedEl);
  }
  if(changes.remaining && typeof changes.remaining.newValue === 'number'){
    remainingEl.textContent = changes.remaining.newValue;
    flashCounter(remainingEl);
    updateProgress(
      parseInt(processedEl.textContent || '0', 10),
      changes.remaining.newValue
    );
  }
  if(changes.stage && typeof changes.stage.newValue === 'number'){
    setStage(changes.stage.newValue);
    const labels = ['', 'Centang item…', 'Klik Arsipkan…', 'Konfirmasi…'];
    if(changes.stage.newValue > 0)
      statusTextEl.textContent = labels[changes.stage.newValue] || 'Running…';
  }
  if(changes.logs && Array.isArray(changes.logs.newValue))
    renderLogs(changes.logs.newValue);
  if(changes.statusMsg?.newValue)
    statusTextEl.textContent = changes.statusMsg.newValue;
});

initState();
