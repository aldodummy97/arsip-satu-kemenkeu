
async function sleep(ms){ return new Promise(r => setTimeout(r, ms)); }

async function addLog(line){
  const ts = new Date().toLocaleTimeString();
  const s  = await chrome.storage.local.get(['logs']);
  const logs = Array.isArray(s.logs) ? s.logs : [];
  logs.push(`[${ts}] ${line}`);
  await chrome.storage.local.set({ logs: logs.slice(-50) });
}

async function setStage(n, msg){
  const u = { stage: n };
  if(msg) u.statusMsg = msg;
  await chrome.storage.local.set(u);
}

// ============================================================
// SUMBER KEBENARAN: angka "dari X" di paginator
// Contoh teks: "1 - 10 dari 445" → return 445
// ============================================================
function readPaginatorTotal(){
  const el = document.querySelector('.mat-paginator-range-label')
          || document.querySelector('.text-12px.font-normal.text-neutral-70');
  if(!el) return null;

  const txt = (el.textContent || '').replace(/\u2013|\u2014/g, '-').trim();
  // Format: "1 - 10 dari 445" atau "1 - 10 dari 74"
  const m = txt.replace(/dari/i, 'of').match(/\d+\s*-\s*\d+\s*of\s*(\d+)/i)
         || txt.replace(/dari/i, 'of').match(/\d+\s*of\s*(\d+)/i);
  if(m) return parseInt(m[1], 10);
  return null;
}

// ============================================================
// SELECTORS
// ============================================================

function findMasterCheckbox(){
  return document.querySelector('.sticky-pagination mat-checkbox .mat-checkbox-input')
      || document.querySelector('.bg-primary-50 mat-checkbox .mat-checkbox-input')
      || document.querySelector('div.flex.flex-row.items-center.pb-4 input.mat-checkbox-input');
}

function findPerItemCheckboxes(){
  return Array.from(document.querySelectorAll('app-naskah-item mat-checkbox input.mat-checkbox-input'));
}

function findCheckedItemCheckboxes(){
  return Array.from(document.querySelectorAll('app-naskah-item mat-checkbox input.mat-checkbox-input:checked'));
}

function countItems(){
  return document.querySelectorAll('app-naskah-item').length;
}

function findToolbarArchive(){
  const areas = ['.sticky-pagination', '.bg-primary-50', 'app-email-action-buttons'];
  for(const area of areas){
    for(const btn of document.querySelectorAll(`${area} button`)){
      const icon = btn.querySelector('mat-icon');
      if(!icon) continue;
      const name = (icon.getAttribute('data-mat-icon-name')||'').toLowerCase();
      const svg  = (icon.getAttribute('svgicon')||'').toLowerCase();
      const tip  = (btn.getAttribute('mattooltip')||'').toLowerCase();
      if(name.includes('archive') || svg.includes('archive') || tip.includes('arsip')) return btn;
    }
  }
  return document.querySelector('app-email-action-buttons [mattooltip="Arsipkan"]') || null;
}

function findConfirmButton(){
  const dialog = document.querySelector('app-dialog-arsip, mat-dialog-container');
  if(dialog){
    const btns = Array.from(dialog.querySelectorAll('button'));
    return btns.find(b => /simpan/i.test((b.textContent||'').trim()))
        || btns.find(b => /arsip/i.test((b.textContent||'').trim()))
        || null;
  }
  return null;
}

// Tunggu dialog tutup + paginator terupdate
async function waitAfterSimpan(delay){
  // 1. Tunggu dialog hilang (max 8 detik)
  for(let i = 0; i < 40; i++){
    if(!document.querySelector('app-dialog-arsip, mat-dialog-container')) break;
    await sleep(200);
  }
  // 2. Tunggu paginator berubah (max delay + 3 detik)
  const before = readPaginatorTotal();
  const deadline = Date.now() + delay + 3000;
  while(Date.now() < deadline){
    await sleep(300);
    const now = readPaginatorTotal();
    // Kalau paginator sudah berubah atau jadi null (list kosong), stop tunggu
    if(now !== before) break;
  }
  await sleep(500); // buffer extra
}

// ============================================================
// MAIN LOOP
// ============================================================
async function runArsip(){
  let cfg     = await chrome.storage.local.get(['running', 'delay']);
  let running = !!cfg.running;
  let delay   = cfg.delay || 2000;

  // totalInitial = angka "dari X" saat start
  const totalInitial = readPaginatorTotal();

  if(totalInitial === null || totalInitial === 0){
    await addLog('Paginator tidak ditemukan atau sudah kosong.');
    await chrome.storage.local.set({ running: false, statusMsg: 'Selesai ✅', stage: 0,
      processed: 0, remaining: 0 });
    return;
  }

  await chrome.storage.local.set({ totalInitial, processed: 0, remaining: totalInitial });
  await addLog(`Start. Total: ${totalInitial}`);

  let totalProcessed   = 0;
  let lastRemaining    = totalInitial; // angka "dari X" terakhir yang dibaca
  let noProgressCycles = 0;

  while(running){

    // Cek sudah kosong belum
    const currentRemaining = readPaginatorTotal();
    if(currentRemaining === 0 || (currentRemaining === null && countItems() === 0)){
      await addLog('✅ Semua Surat Sudah Diarsipkan');
      await chrome.storage.local.set({ running: false, statusMsg: 'Selesai ✅', stage: 0,
        processed: totalProcessed, remaining: 0 });
      break;
    }

    let didWork = false;

    // ── STEP 1: Centang ──
    await setStage(1, 'Mencentang item…');
    const master   = findMasterCheckbox();
    const perItems = findPerItemCheckboxes();

    if(master){
      const label = master.closest('.mat-checkbox-layout') || master.closest('label');
      if(label) label.click(); else master.click();
      await sleep(300);
      if(findCheckedItemCheckboxes().length > 0){ didWork = true; await addLog('Centang semua item.'); }
    } else if(perItems.length > 0){
      perItems.forEach(cb => { if(!cb.checked) cb.click(); });
      await sleep(300);
      if(findCheckedItemCheckboxes().length > 0){ didWork = true; await addLog(`Centang ${perItems.length} item.`); }
    } else {
      await addLog('Tidak ada checkbox ditemukan.');
    }

    await sleep(delay);

    // ── STEP 2: Klik arsip toolbar ──
    await setStage(2, 'Klik Arsipkan…');
    const tb      = findToolbarArchive();
    const checked = findCheckedItemCheckboxes();

    if(tb && checked.length > 0){
      tb.click();
      didWork = true;
      await addLog(`Klik Arsipkan (${checked.length} item).`);
      await sleep(delay); // tunggu dialog muncul
    } else {
      if(!tb) await addLog('Tombol arsip tidak ditemukan.');
    }

    // ── STEP 3: Simpan di dialog ──
    await setStage(3, 'Konfirmasi dialog…');
    const conf = findConfirmButton();
    if(conf){
      conf.click();
      didWork = true;
      await addLog('Klik Simpan.');
      await waitAfterSimpan(delay);
    } else {
      await sleep(500);
    }

    // ── Hitung processed dari selisih "dari X" ──
    const newRemaining = readPaginatorTotal() ?? 0;
    const batchDone    = Math.max(0, lastRemaining - newRemaining);
    totalProcessed    += batchDone;
    lastRemaining      = newRemaining;

    await chrome.storage.local.set({ processed: totalProcessed, remaining: newRemaining });
    await addLog(`Batch: +${batchDone} | Processed: ${totalProcessed} | Remaining: ${newRemaining}`);

    if(batchDone > 0){
      noProgressCycles = 0;
    } else if(!didWork){
      noProgressCycles++;
    } else {
      noProgressCycles = Math.max(0, noProgressCycles - 1);
    }

    // Recovery jika stuck
    if(noProgressCycles >= 5){
      await addLog('⚠️ Tidak ada progres, retry…');
      noProgressCycles = 0;
      await sleep(delay * 2);
    }

    cfg     = await chrome.storage.local.get(['running', 'delay']);
    running = !!cfg.running;
    delay   = cfg.delay || delay;
  }
}

runArsip();
